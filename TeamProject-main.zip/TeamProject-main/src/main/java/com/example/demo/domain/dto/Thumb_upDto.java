package com.example.demo.domain.dto;

import lombok.Data;

@Data
public class Thumb_upDto {
    private Long no;
    private Boolean thumb_up;
    private Long rno;
    private String username;

}
